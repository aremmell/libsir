/*
 *  main.c : Example usage of the ANSI C Implementation of 
 *  Standard Incident Reporter (SIR)
 *
 *  Copyright 2003-2004 - All Rights Reserved
 *
 *  Author:
 *    Ryan Matthew Lederman
 *    ryan@ript.net
 *
 *  Date:
 *    January 02, 2005
 *
 *  Version: 1.0.4
 *
 *  License:
 *    This software is provided to the end user "as-is", with no warranty
 *    implied or otherwise.  The author is for all intents and purposes
 *    the owner of this source code.  The author grants the end user the
 *    privilege to use this software in any application, commercial or
 *    otherwise, with the following restrictions:
 *      1.) If the end user wishes to modify this source code, he/she must
 *       not distribute the source code as the original source code, and
 *       must clearly document the changes made to the source code in any
 *       distribution of said source code.
 *      2.) This license agreement must always be displayed in any version
 *       of the source code.
 *    The author will not be held liable for ANY damage, loss of data,
 *    loss of income, or any other form of loss that results directly or 
 *    indirectly from the use of this software.
 *
 */
#include "sir.h"

/*
  Sir type callback function
 */
void SirCallback(TCHAR *out, u_long data);

int main(int argc, TCHAR *argv[]) {

  SIRSTRUCT ss = {0}; /* Declare the Sir initialization structure */

  /*
    Output of types SIRT_LOG and SIRT_WARNING
    will be sent to stdout.
   */
  ss.f_stdout = SIRT_LOG | SIRT_WARNING;

  /*
    Output of type SIRT_WARNING will be sent
    to debug.
   */
  ss.f_debug  = SIRT_WARNING;

  /*
    Output of types SIRT_ERROR and SIRT_FATAL
    will be sent to stderr.
   */
  ss.f_stderr = SIRT_ERROR | SIRT_FATAL;

  /*
    Set the option bits (sir.h);
    SIRO_CRLF       = \r\n will be appended to output,
    SIRO_TIMESTAMP  = Time will be prepended to output,
    SIRO_FILES      = Sir will handle file output,
    SIRO_CALLBACKS  = Sir will handle callback output
    SIRO_NODBGCRLF  = \r will be stripped from debug output so
                      that double-spacing does not occur.
   */
  ss.opts = SIRO_CRLF | SIRO_TIMESTAMP | SIRO_FILES | SIRO_CALLBACKS | SIRO_NODBGCRLF;

  /*
    Initialize the Sir system.
   */
  if (0 != Sir_Init(&ss)) {

    printf("Failed to initialize the Sir system!!\n");
    return 1;

  } else {

    printf("Successfully initialized the Sir system.\n");

  }

  /*
    Add a file for output of types SIRT_WARNING and SIRT_LOG.
   */
  if (0 != Sir_AddFile(_T("sir.log"), SIRT_WARNING | SIRT_LOG)) {

    printf("Failed to add file to Sir system!!\n");

  } else {

    printf("Successfully associated 'sir.log' with SIRT_WARNING"
           " and SIRT_LOG output types.\n");

  }

  /*
    Add a callback for output types of SIRT_SCREEN.
   */
  if (0 != Sir_AddCallback(SirCallback, SIRT_SCREEN, 0UL)) {

    printf("Failed to add callback to Sir system!!\n");

  } else {

    printf("Successfully associated SirCallback() with SIRT_SCREEN"
           " output type.\n");

  }

  /*
    Send output to all its destinations with one call!
   */

  /*
    Sent to all destinations associated with type SIRT_WARNING or SIRT_LOG
    (or both).
   */
  Sir(SIRT_WARNING | SIRT_LOG, _T("This is a test of the Sir system. This is")
      _T(" only a test. %d, %d, %d"), 1, 2, 3);

  /*
    Sent to all destinations associated with type SIRT_ERROR or SIRT_SCREEN
    (or both).
   */
  Sir(SIRT_ERROR | SIRT_SCREEN, "This is a continuation of the Sir system"
      " test.");

  /*
    Remove the file and callback (disassociates them with output types).
   */
  Sir_RemFile(_T("sir.log"));
  Sir_RemCallback(SirCallback);

  /*
    Free allocated resources and reset
    the system's state
   */
  Sir_Cleanup();

  return 0;
}

void SirCallback(TCHAR *out, u_long data) {
  printf("SirCallback() : Recieved string %s, Data = %lo\n", out, data);
}
